var CommonConstant = artifacts.require("./CommonConstant.sol");

module.exports = function(deployer) {
  deployer.deploy(CommonConstant);
};
