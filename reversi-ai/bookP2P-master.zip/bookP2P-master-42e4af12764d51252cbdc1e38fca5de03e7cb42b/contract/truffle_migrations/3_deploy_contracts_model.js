var CNS = artifacts.require("./CNS.sol");
var BookInfo = artifacts.require("./BookInfo.sol");
var UserInfo = artifacts.require("./UserInfo.sol");
var RentalTrn = artifacts.require("./RentalTrn.sol");
var RequestTrn = artifacts.require("./RequestTrn.sol");

module.exports = function(deployer) {
  deployer.deploy(CNS);
  deployer.deploy(BookInfo);
  deployer.deploy(UserInfo);
  deployer.deploy(RentalTrn);
  deployer.deploy(RequestTrn);
};
