var BookLogic = artifacts.require("./BookLogic.sol");
var UserLogic = artifacts.require("./UserLogic.sol");
var TransactionLogic = artifacts.require("./TransactionLogic.sol");

module.exports = function(deployer) {
  deployer.deploy(BookLogic,"0x3e63d5ca4394bf5bebf9f75ae84620dd5b4ae3c2");
  deployer.deploy(UserLogic,"0x3e63d5ca4394bf5bebf9f75ae84620dd5b4ae3c2");
  deployer.deploy(TransactionLogic,"0x3e63d5ca4394bf5bebf9f75ae84620dd5b4ae3c2");
};
