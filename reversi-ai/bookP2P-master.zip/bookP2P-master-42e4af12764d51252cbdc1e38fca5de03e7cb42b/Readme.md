BookP2P
====

Overview  
書籍のP2P取引をEthereumベースで動かすためのアプリケーション  
  
Client->各ユースのデスクトップ上で動作させるアプリケーション  
Upload Server->書籍をスマホからアップロードするためのサーバアプリ  

## Install
node.jsで動作しています。  
node.jsと最新版のnpmをインストールのうえ、  
npm installでモジュールをインストールしてください。  

## Description
