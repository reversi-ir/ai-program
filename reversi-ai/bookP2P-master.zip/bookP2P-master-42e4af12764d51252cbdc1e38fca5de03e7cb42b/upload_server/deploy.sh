#!/bin/sh
gcloud app deploy --project tensile-sorter-170103

